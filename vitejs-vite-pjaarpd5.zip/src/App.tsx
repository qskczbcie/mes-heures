import React, { useState, useEffect, useMemo } from 'react';
import { initializeApp } from 'firebase/app';
import {
  getAuth,
  signInWithPopup,
  GoogleAuthProvider,
  signOut,
  onAuthStateChanged,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
} from 'firebase/auth';
import {
  getFirestore,
  collection,
  addDoc,
  query,
  where,
  onSnapshot,
  deleteDoc,
  doc,
  orderBy,
  serverTimestamp,
  getDocs,
  setDoc,
  writeBatch,
} from 'firebase/firestore';
import {
  Play,
  Pause,
  Square,
  Clock,
  Calendar,
  Moon,
  Sun,
  LogOut,
  FileText,
  Users,
  PlusCircle,
  Trash2,
  Printer,
  X,
  AlertCircle,
  CheckCircle,
  Coffee,
  Camera,
  Loader2,
  Save,
  Eye,
} from 'lucide-react';

// ------------------------------------------------------------------
// ZONE DE CONFIGURATION (C'est ici que vous devrez coller votre code !)
// ------------------------------------------------------------------

const firebaseConfig = {
  apiKey: 'AIzaSyAmtx41AkUJWcglA8Q0sR02aBQtdMRlRJQ',
  authDomain: 'mes-prestations.firebaseapp.com',
  projectId: 'mes-prestations',
  storageBucket: 'mes-prestations.firebasestorage.app',
  messagingSenderId: '989827417620',
  appId: '1:989827417620:web:423261b26bd57929744901',
  measurementId: 'G-QYB0X8E0LY',
};

// ------------------------------------------------------------------
// Fin de la configuration
// ------------------------------------------------------------------

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);
// On utilise un ID fixe pour l'app publique
const appId = 'mes-heures-app';

// --- Utilitaires ---

const fileToBase64 = (file) => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      const base64String = reader.result.split(',')[1];
      resolve(base64String);
    };
    reader.onerror = (error) => reject(error);
  });
};

const calculateDayNightSplit = (start, end) => {
  let current = new Date(start);
  const finish = new Date(end);
  let dayMinutes = 0;
  let nightMinutes = 0;

  if (finish < current) return { dayHours: 0, nightHours: 0, totalHours: 0 };

  while (current < finish) {
    const hour = current.getHours();
    const isNight = hour >= 20 || hour < 6;
    if (isNight) nightMinutes++;
    else dayMinutes++;
    current.setMinutes(current.getMinutes() + 1);
  }

  return {
    dayHours: dayMinutes / 60,
    nightHours: nightMinutes / 60,
    totalHours: (dayMinutes + nightMinutes) / 60,
  };
};

const getWeekNumber = (d) => {
  d = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
  d.setUTCDate(d.getUTCDate() + 4 - (d.getUTCDay() || 7));
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  const weekNo = Math.ceil(((d - yearStart) / 86400000 + 1) / 7);
  return weekNo;
};

const formatDuration = (hours) => {
  const h = Math.floor(hours);
  const m = Math.round((hours - h) * 60);
  return `${h}h ${m < 10 ? '0' : ''}${m}`;
};

// --- Composants ---

const Auth = ({ setUser }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [error, setError] = useState('');

  const handleGoogle = async () => {
    const provider = new GoogleAuthProvider();
    try {
      const result = await signInWithPopup(auth, provider);
      const userRef = doc(db, 'users', result.user.uid);
      await setDoc(
        userRef,
        {
          email: result.user.email,
          name: result.user.displayName || 'Utilisateur',
          role:
            result.user.email && result.user.email.includes('admin')
              ? 'admin'
              : 'employee',
        },
        { merge: true }
      );
    } catch (e) {
      setError(e.message);
    }
  };

  const handleEmailAuth = async (e) => {
    e.preventDefault();
    try {
      let result;
      if (isLogin) {
        result = await signInWithEmailAndPassword(auth, email, password);
      } else {
        result = await createUserWithEmailAndPassword(auth, email, password);
        const userRef = doc(db, 'users', result.user.uid);
        await setDoc(userRef, {
          email: email,
          name: name,
          role: email.includes('admin') ? 'admin' : 'employee',
        });
      }
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center neu-bg p-4 font-sans text-slate-200">
      <div className="neu-flat p-8 rounded-[30px] w-full max-w-md border border-white/5">
        <div className="flex justify-center mb-6">
          <div className="neu-icon-btn w-16 h-16 flex items-center justify-center text-white">
            <Clock size={32} />
          </div>
        </div>
        <h1 className="text-2xl font-bold text-center mb-8 text-white glow-text tracking-wide">
          Mes <span className="text-white font-normal">Heures</span>
        </h1>
        {error && (
          <div className="neu-pressed bg-white/5 text-white p-3 rounded-xl mb-6 text-sm text-center border border-white/10">
            {error}
          </div>
        )}

        <form onSubmit={handleEmailAuth} className="space-y-6">
          {!isLogin && (
            <input
              type="text"
              placeholder="Nom complet"
              className="w-full p-4 rounded-xl neu-pressed outline-none bg-transparent text-white placeholder-slate-500 glow-input"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
            />
          )}
          <input
            type="email"
            placeholder="Email"
            className="w-full p-4 rounded-xl neu-pressed outline-none bg-transparent text-white placeholder-slate-500 glow-input"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
          <input
            type="password"
            placeholder="Mot de passe"
            className="w-full p-4 rounded-xl neu-pressed outline-none bg-transparent text-white placeholder-slate-500 glow-input"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />

          <button
            type="submit"
            className="w-full py-4 rounded-xl neu-btn text-white font-bold hover:text-slate-200 transition-colors uppercase tracking-wider text-sm glow-text"
          >
            {isLogin ? 'Connexion' : 'Inscription'}
          </button>
        </form>

        <div className="mt-8 text-center">
          <button
            onClick={handleGoogle}
            className="text-sm font-medium text-slate-400 hover:text-white transition"
          >
            Continuer avec Google
          </button>
        </div>

        <div className="mt-6 text-center">
          <button
            onClick={() => setIsLogin(!isLogin)}
            className="text-sm text-slate-500 hover:text-slate-300"
          >
            {isLogin ? 'Créer un compte' : "J'ai déjà un compte"}
          </button>
        </div>
      </div>
    </div>
  );
};

// --- Composant d'Aperçu PDF (Modal) ---
const PdfPreviewModal = ({ isOpen, onClose, entries, stats, userData }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/80 z-[100] flex items-start justify-center overflow-y-auto p-4 backdrop-blur-md animate-in fade-in">
      <div className="neu-bg rounded-[30px] p-2 w-full max-w-3xl my-8 flex flex-col shadow-2xl border border-white/10">
        <div className="p-4 flex justify-between items-center rounded-t-[25px]">
          <h3 className="font-bold text-white glow-text flex items-center gap-2">
            <FileText size={20} className="text-white" /> Aperçu Document
          </h3>
          <div className="flex gap-4">
            <button
              onClick={onClose}
              className="w-10 h-10 rounded-full neu-btn flex items-center justify-center text-slate-400 hover:text-white"
            >
              <X size={20} />
            </button>
            <button
              onClick={() => window.print()}
              className="px-6 py-2 neu-btn rounded-xl text-white font-bold flex items-center gap-2 hover:text-slate-200"
            >
              <Printer size={18} /> Imprimer
            </button>
          </div>
        </div>

        <div className="p-4 overflow-auto bg-[#1a1d21] rounded-[20px] m-2">
          <div
            id="pdf-preview-content"
            className="p-12 bg-white text-slate-900 min-h-[29.7cm] text-sm shadow-lg mx-auto max-w-[21cm]"
          >
            <div className="flex justify-between items-start mb-12 border-b-2 border-slate-800 pb-4">
              <div>
                <h1 className="text-2xl font-bold uppercase tracking-wider mb-2 text-slate-900">
                  Relevé de Prestations
                </h1>
                <p className="text-slate-500">
                  Période:{' '}
                  {new Date().toLocaleDateString('fr-BE', {
                    month: 'long',
                    year: 'numeric',
                  })}
                </p>
              </div>
              <div className="text-right">
                <h2 className="font-bold text-lg text-slate-900">
                  {userData?.name || 'Employé'}
                </h2>
                <p className="text-slate-500 text-xs">{userData?.email}</p>
                <div className="mt-2 text-xs bg-slate-100 p-2 rounded inline-block text-left text-slate-600">
                  <p>Contrat: 30h/sem</p>
                  <p>Nuit: 20h-06h</p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-4 gap-4 mb-8">
              <div className="border border-slate-200 p-3 rounded text-center">
                <p className="text-xs text-slate-500 uppercase">Total Heures</p>
                <p className="text-xl font-bold text-slate-800">
                  {formatDuration(stats.totalWorked)}
                </p>
              </div>
              <div className="border border-slate-200 p-3 rounded text-center">
                <p className="text-xs text-slate-500 uppercase">Heures Nuit</p>
                <p className="text-xl font-bold text-slate-700">
                  {formatDuration(stats.nightHoursTotal)}
                </p>
              </div>
              <div className="border border-slate-200 p-3 rounded text-center">
                <p className="text-xs text-slate-500 uppercase">Heures Jour</p>
                <p className="text-xl font-bold text-slate-600">
                  {formatDuration(stats.dayHoursTotal)}
                </p>
              </div>
              <div className="border border-slate-200 p-3 rounded text-center bg-slate-50">
                <p className="text-xs text-slate-500 uppercase">Récupération</p>
                <p className="text-xl font-bold text-slate-600">
                  {formatDuration(stats.overtimeTotal)}
                </p>
              </div>
            </div>

            <table className="w-full text-left border-collapse mb-12">
              <thead>
                <tr className="border-b-2 border-slate-300">
                  <th className="py-2 text-xs uppercase text-slate-500 font-semibold w-32">
                    Date
                  </th>
                  <th className="py-2 text-xs uppercase text-slate-500 font-semibold">
                    Horaires
                  </th>
                  <th className="py-2 text-xs uppercase text-slate-500 font-semibold text-center">
                    Total
                  </th>
                  <th className="py-2 text-xs uppercase text-slate-500 font-semibold text-center">
                    Nuit
                  </th>
                  <th className="py-2 text-xs uppercase text-slate-500 font-semibold text-center">
                    Type
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {entries.map((entry) => {
                  if (!entry.endTime && entry.type !== 'off') return null;

                  const start = entry.startTime.toDate
                    ? entry.startTime.toDate()
                    : new Date(entry.startTime);
                  let end, details;

                  if (entry.type === 'off') {
                    details = { totalHours: 0, nightHours: 0, dayHours: 0 };
                  } else {
                    end = entry.endTime.toDate
                      ? entry.endTime.toDate()
                      : new Date(entry.endTime);
                    details = calculateDayNightSplit(start, end);
                  }

                  return (
                    <tr key={entry.id} className="text-sm text-slate-700">
                      <td className="py-3 font-medium">
                        {start.toLocaleDateString('fr-BE', {
                          day: '2-digit',
                          month: '2-digit',
                          year: 'numeric',
                        })}
                      </td>
                      <td className="py-3 text-slate-600">
                        {entry.type === 'off' ? (
                          <span className="italic">Récupération</span>
                        ) : (
                          `${start.toLocaleTimeString('fr-BE', {
                            hour: '2-digit',
                            minute: '2-digit',
                          })} - ${end.toLocaleTimeString('fr-BE', {
                            hour: '2-digit',
                            minute: '2-digit',
                          })}`
                        )}
                      </td>
                      <td className="py-3 text-center font-bold">
                        {entry.type === 'off'
                          ? '-'
                          : formatDuration(details.totalHours)}
                      </td>
                      <td className="py-3 text-center text-slate-700">
                        {!entry.type !== 'off' && details.nightHours > 0
                          ? formatDuration(details.nightHours)
                          : '-'}
                      </td>
                      <td className="py-3 text-center text-xs">
                        {entry.type === 'off'
                          ? 'Récupération'
                          : entry.isManual
                          ? 'Manuel'
                          : 'Pointage'}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>

            <div className="mt-20 border-t border-slate-200 pt-4 text-center text-[10px] text-slate-300">
              Généré par Mes Heures - {new Date().toISOString()}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const Dashboard = ({ currentUser, logout }) => {
  const [entries, setEntries] = useState([]);
  const [selectedUserId, setSelectedUserId] = useState(currentUser.uid);
  const [userData, setUserData] = useState(null);
  const [timerStart, setTimerStart] = useState(null);
  const [activeEntryId, setActiveEntryId] = useState(null);
  const [manualStart, setManualStart] = useState('');
  const [manualEnd, setManualEnd] = useState('');
  const [manualDate, setManualDate] = useState(
    new Date().toISOString().split('T')[0]
  );
  const [isOffDay, setIsOffDay] = useState(false);
  const [showManualForm, setShowManualForm] = useState(false);
  const [scannedEntries, setScannedEntries] = useState([]);
  const [showBulkReview, setShowBulkReview] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [showPdfPreview, setShowPdfPreview] = useState(false);
  const [deleteId, setDeleteId] = useState(null);
  const [notification, setNotification] = useState(null);
  const [elapsed, setElapsed] = useState(0);

  useEffect(() => {
    let interval;
    if (timerStart) {
      interval = setInterval(() => {
        setElapsed(new Date() - new Date(timerStart));
      }, 1000);
    } else {
      setElapsed(0);
    }
    return () => clearInterval(interval);
  }, [timerStart]);

  useEffect(() => {
    if (notification) {
      const timer = setTimeout(() => setNotification(null), 3000);
      return () => clearTimeout(timer);
    }
  }, [notification]);

  useEffect(() => {
    const fetchUserData = async () => {
      const userRef = doc(db, 'users', currentUser.uid);
      const snap = await getDocs(query(collection(db, 'users')));
    };
    fetchUserData();
  }, [currentUser]);

  useEffect(() => {
    if (!selectedUserId) return;

    const profileUnsub = onSnapshot(doc(db, 'users', selectedUserId), (doc) => {
      if (doc.exists()) setUserData(doc.data());
      else
        setUserData({
          name: 'Utilisateur',
          role: 'employee',
          contractHours: 30,
        });
    });

    const q = query(
      collection(db, 'users', selectedUserId, 'entries'),
      orderBy('startTime', 'desc')
    );

    const unsub = onSnapshot(
      q,
      (snapshot) => {
        const fetchedEntries = snapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }));
        setEntries(fetchedEntries);

        const active = fetchedEntries.find(
          (e) => !e.endTime && e.type !== 'off'
        );
        if (active) {
          setTimerStart(active.startTime.toDate());
          setActiveEntryId(active.id);
        } else {
          setTimerStart(null);
          setActiveEntryId(null);
        }
      },
      (error) => console.error('Error fetching entries:', error)
    );

    return () => {
      unsub();
      profileUnsub();
    };
  }, [selectedUserId]);

  const showToast = (type, message) => {
    setNotification({ type, message });
  };

  const handleStart = async () => {
    try {
      await addDoc(collection(db, 'users', selectedUserId, 'entries'), {
        startTime: serverTimestamp(),
        endTime: null,
        type: 'work',
        created: serverTimestamp(),
      });
      showToast('success', 'Chronomètre démarré');
    } catch (e) {
      console.error(e);
      showToast('error', 'Erreur lors du démarrage');
    }
  };

  const handleStop = async () => {
    if (!activeEntryId) return;
    try {
      const ref = doc(db, 'users', selectedUserId, 'entries', activeEntryId);
      await setDoc(ref, { endTime: serverTimestamp() }, { merge: true });
      setTimerStart(null);
      setActiveEntryId(null);
      showToast('success', 'Session terminée enregistrée');
    } catch (e) {
      console.error(e);
      showToast('error', "Erreur lors de l'arrêt");
    }
  };

  const handleImageAnalysis = async (e) => {
    // Note: Pour que l'IA fonctionne sur StackBlitz, il faut une clé API Gemini.
    // Sans clé, cette fonction simulera ou échouera.
    showToast(
      'error',
      'Configuration IA manquante sur cette version en ligne.'
    );
  };

  const handleBulkSave = async () => {
    setIsAnalyzing(true);
    const batch = writeBatch(db);
    try {
      scannedEntries.forEach((entry) => {
        if (!entry.date || !entry.start) return;
        let startDate = new Date(`${entry.date}T${entry.start}`);
        let endDate = new Date(`${entry.date}T${entry.end}`);
        if (endDate <= startDate) endDate.setDate(endDate.getDate() + 1);
        const docRef = doc(collection(db, 'users', selectedUserId, 'entries'));
        batch.set(docRef, {
          startTime: startDate,
          endTime: endDate,
          type: 'work',
          created: serverTimestamp(),
          isManual: true,
          source: 'scan_bulk',
        });
      });
      await batch.commit();
      setScannedEntries([]);
      setShowBulkReview(false);
      showToast('success', 'Toutes les entrées ont été ajoutées !');
    } catch (e) {
      showToast('error', 'Erreur lors de la sauvegarde groupée');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const updateScannedEntry = (index, field, value) => {
    const updated = [...scannedEntries];
    updated[index][field] = value;
    setScannedEntries(updated);
  };
  const removeScannedEntry = (index) => {
    const updated = scannedEntries.filter((_, i) => i !== index);
    setScannedEntries(updated);
  };

  const handleManualAdd = async (e) => {
    e.preventDefault();
    const isEmptyHours = !manualStart || !manualEnd;

    if (isOffDay || isEmptyHours) {
      const start = new Date(`${manualDate}T00:00`);
      const end = new Date(`${manualDate}T00:00`);
      try {
        await addDoc(collection(db, 'users', selectedUserId, 'entries'), {
          startTime: start,
          endTime: end,
          type: 'off',
          created: serverTimestamp(),
          isManual: true,
        });
        setShowManualForm(false);
        showToast('success', 'Jour de Récupération ajouté');
        setIsOffDay(false);
        setManualStart('');
        setManualEnd('');
      } catch (e) {
        showToast('error', "Erreur d'ajout");
      }
      return;
    }

    const start = new Date(`${manualDate}T${manualStart}`);
    const end = new Date(`${manualDate}T${manualEnd}`);
    if (end <= start) {
      showToast('error', "L'heure de fin doit être après l'heure de début");
      return;
    }

    try {
      await addDoc(collection(db, 'users', selectedUserId, 'entries'), {
        startTime: start,
        endTime: end,
        type: 'work',
        created: serverTimestamp(),
        isManual: true,
      });
      setManualStart('');
      setManualEnd('');
      setShowManualForm(false);
      showToast('success', 'Entrée ajoutée');
    } catch (e) {
      showToast('error', "Erreur d'ajout");
    }
  };

  const initiateDelete = (id) => {
    setDeleteId(id);
  };
  const confirmDelete = async () => {
    if (!deleteId) return;
    try {
      await deleteDoc(doc(db, 'users', selectedUserId, 'entries', deleteId));
      showToast('success', 'Entrée supprimée');
    } catch (e) {
      showToast('error', 'Impossible de supprimer');
    } finally {
      setDeleteId(null);
    }
  };

  const stats = useMemo(() => {
    let totalWorked = 0;
    let nightHoursTotal = 0;
    let dayHoursTotal = 0;
    let weeks = {};
    entries.forEach((entry) => {
      if (entry.endTime && entry.startTime && entry.type !== 'off') {
        const start = entry.startTime.toDate
          ? entry.startTime.toDate()
          : new Date(entry.startTime);
        const end = entry.endTime.toDate
          ? entry.endTime.toDate()
          : new Date(entry.endTime);
        const split = calculateDayNightSplit(start, end);
        totalWorked += split.totalHours;
        nightHoursTotal += split.nightHours;
        dayHoursTotal += split.dayHours;
        const weekNum = getWeekNumber(start);
        if (!weeks[weekNum]) weeks[weekNum] = 0;
        weeks[weekNum] += split.totalHours;
      }
    });
    let overtimeTotal = 0;
    Object.values(weeks).forEach((hoursInWeek) => {
      if (hoursInWeek > 30) overtimeTotal += hoursInWeek - 30;
    });
    return {
      totalWorked,
      nightHoursTotal,
      dayHoursTotal,
      overtimeTotal,
      remainingContract: Math.max(
        0,
        30 - (weeks[getWeekNumber(new Date())] || 0)
      ),
    };
  }, [entries]);

  const isAdmin = currentUser.email
    ? currentUser.email.includes('admin')
    : false;

  return (
    <div className="min-h-screen neu-bg font-sans relative text-slate-200">
      <style>{`
        :root { --neu-base: #292d32; --neu-shadow-light: #353b41; --neu-shadow-dark: #1d2024; }
        .neu-bg { background-color: var(--neu-base); }
        .neu-flat { background-color: var(--neu-base); box-shadow: 7px 7px 15px var(--neu-shadow-dark), -7px -7px 15px var(--neu-shadow-light); border-radius: 20px; }
        .neu-pressed { background-color: var(--neu-base); box-shadow: inset 5px 5px 10px var(--neu-shadow-dark), inset -5px -5px 10px var(--neu-shadow-light); border-radius: 15px; }
        .neu-btn { background-color: var(--neu-base); box-shadow: 5px 5px 10px var(--neu-shadow-dark), -5px -5px 10px var(--neu-shadow-light); transition: all 0.2s ease; border-radius: 12px; }
        .neu-btn:active { box-shadow: inset 3px 3px 6px var(--neu-shadow-dark), inset -3px -3px 6px var(--neu-shadow-light); transform: translateY(1px); }
        .neu-icon-btn { width: 40px; height: 40px; border-radius: 50%; display: flex; align-items: center; justify-content: center; background-color: var(--neu-base); box-shadow: 5px 5px 10px var(--neu-shadow-dark), -5px -5px 10px var(--neu-shadow-light); transition: all 0.2s ease; }
        .neu-icon-btn:active { box-shadow: inset 3px 3px 6px var(--neu-shadow-dark), inset -3px -3px 6px var(--neu-shadow-light); }
        .glow-text { color: white; text-shadow: 0 0 10px rgba(255, 255, 255, 0.4); }
        .glow-input { text-shadow: 0 0 5px rgba(255, 255, 255, 0.2); }
        ::-webkit-scrollbar { width: 8px; }
        ::-webkit-scrollbar-track { background: var(--neu-base); }
        ::-webkit-scrollbar-thumb { background: #4b5563; border-radius: 4px; }
        input[type="date"]::-webkit-calendar-picker-indicator, input[type="time"]::-webkit-calendar-picker-indicator { filter: invert(1); opacity: 0.6; cursor: pointer; }
      `}</style>

      {notification && (
        <div
          className={`fixed top-4 right-4 z-[200] px-6 py-4 rounded-2xl shadow-xl flex items-center gap-3 transition-all transform animate-in slide-in-from-top-5 neu-flat text-white border-l-4 border-white`}
        >
          {notification.type === 'success' ? (
            <CheckCircle size={20} />
          ) : (
            <AlertCircle size={20} />
          )}
          <span className="font-medium glow-text">{notification.message}</span>
        </div>
      )}

      {deleteId && (
        <div className="fixed inset-0 bg-black/60 z-[150] flex items-center justify-center p-4 backdrop-blur-sm animate-in fade-in">
          <div className="neu-flat p-8 w-full max-w-sm border border-white/5">
            <h3 className="text-lg font-bold text-white glow-text mb-2">
              Confirmer la suppression
            </h3>
            <p className="text-slate-400 mb-6 text-sm">Action irréversible.</p>
            <div className="flex justify-end gap-4">
              <button
                onClick={() => setDeleteId(null)}
                className="px-6 py-2 neu-btn text-slate-400 hover:text-white"
              >
                Annuler
              </button>
              <button
                onClick={confirmDelete}
                className="px-6 py-2 neu-btn text-white font-bold hover:text-slate-200 active:text-slate-300"
              >
                Supprimer
              </button>
            </div>
          </div>
        </div>
      )}

      {showBulkReview && (
        <div className="fixed inset-0 bg-black/60 z-[150] flex items-center justify-center p-4 backdrop-blur-sm animate-in fade-in">
          <div className="neu-flat p-6 max-w-4xl w-full max-h-[90vh] overflow-hidden flex flex-col border border-white/5">
            <div className="flex justify-between items-center mb-6">
              <div>
                <h3 className="text-xl font-bold text-white glow-text flex items-center gap-2">
                  <Camera className="text-white" /> Validation du Scan
                </h3>
                <p className="text-sm text-slate-400">
                  {scannedEntries.length} entrées détectées.
                </p>
              </div>
              <button
                onClick={() => setShowBulkReview(false)}
                className="neu-icon-btn text-slate-400 hover:text-white"
              >
                <X size={20} />
              </button>
            </div>
            <div className="overflow-y-auto flex-1 neu-pressed p-4 mb-6 rounded-xl">
              <table className="w-full text-sm text-left">
                <thead className="text-slate-400 uppercase font-bold text-xs sticky top-0">
                  <tr>
                    <th className="p-3">Date</th>
                    <th className="p-3">Début</th>
                    <th className="p-3">Fin</th>
                    <th className="p-3 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {scannedEntries.map((entry, idx) => (
                    <tr key={idx} className="hover:bg-white/5 transition">
                      <td className="p-2">
                        <input
                          type="date"
                          value={entry.date}
                          onChange={(e) =>
                            updateScannedEntry(idx, 'date', e.target.value)
                          }
                          className="w-full p-2 rounded-lg neu-pressed bg-transparent border-none outline-none text-white glow-input"
                        />
                      </td>
                      <td className="p-2">
                        <input
                          type="time"
                          value={entry.start}
                          onChange={(e) =>
                            updateScannedEntry(idx, 'start', e.target.value)
                          }
                          className="w-full p-2 rounded-lg neu-pressed bg-transparent border-none outline-none text-white glow-input"
                        />
                      </td>
                      <td className="p-2">
                        <input
                          type="time"
                          value={entry.end}
                          onChange={(e) =>
                            updateScannedEntry(idx, 'end', e.target.value)
                          }
                          className="w-full p-2 rounded-lg neu-pressed bg-transparent border-none outline-none text-white glow-input"
                        />
                      </td>
                      <td className="p-2 text-right">
                        <button
                          onClick={() => removeScannedEntry(idx)}
                          className="text-white hover:text-slate-300 p-2"
                        >
                          <Trash2 size={16} />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="flex justify-end gap-4">
              <button
                onClick={() => setShowBulkReview(false)}
                className="px-6 py-3 neu-btn text-slate-400 font-medium hover:text-white"
              >
                Annuler
              </button>
              <button
                onClick={handleBulkSave}
                disabled={isAnalyzing}
                className="px-8 py-3 neu-btn text-white font-bold flex items-center gap-2 hover:text-slate-200 active:scale-95 transition-transform glow-text"
              >
                {isAnalyzing ? (
                  <Loader2 className="animate-spin" size={18} />
                ) : (
                  <Save size={18} />
                )}{' '}
                Tout Valider
              </button>
            </div>
          </div>
        </div>
      )}

      <PdfPreviewModal
        isOpen={showPdfPreview}
        onClose={() => setShowPdfPreview(false)}
        entries={entries}
        stats={stats}
        userData={userData}
      />

      <header className="neu-bg p-4 sticky top-0 z-50 print:hidden">
        <div className="max-w-7xl mx-auto flex justify-between items-center neu-flat px-6 py-4 rounded-[20px] border border-white/5">
          <div className="flex items-center gap-4">
            <div className="neu-icon-btn text-white">
              <Clock size={20} />
            </div>
            <div>
              <h1 className="text-lg font-bold text-white tracking-wide glow-text">
                Mes <span className="text-white font-normal">Heures</span>
              </h1>
              <p className="text-xs text-slate-400 font-medium">
                {userData?.name || currentUser.displayName || 'Utilisateur'}
                {isAdmin && (
                  <span className="ml-2 text-white font-bold border border-white/30 px-2 rounded-full text-[10px] glow-text">
                    ADMIN
                  </span>
                )}
              </p>
            </div>
          </div>
          <div className="flex gap-4">
            <button
              onClick={() => setShowPdfPreview(true)}
              className="px-4 py-2 neu-btn text-slate-300 hover:text-white flex items-center gap-2 transition-colors glow-text"
            >
              <Eye size={18} />{' '}
              <span className="hidden sm:inline font-medium">Aperçu</span>
            </button>
            <button
              onClick={logout}
              className="neu-icon-btn text-slate-400 hover:text-white"
            >
              <LogOut size={18} />
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto p-4 md:p-8 space-y-8">
        {isAdmin && (
          <div className="neu-flat p-4 flex items-center gap-3 text-white print:hidden border border-white/20">
            <div className="neu-icon-btn text-white">
              <Users size={18} />
            </div>
            <div>
              <p className="font-bold glow-text">Mode Administrateur</p>
              <p className="text-xs text-slate-400">Vue globale active.</p>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 print:grid-cols-4">
          <div className="neu-flat p-6 flex items-center justify-between border border-white/5">
            <div>
              <p className="text-slate-400 text-xs font-bold uppercase tracking-wider mb-1">
                Total Presté
              </p>
              <h3 className="text-2xl font-bold text-white glow-text">
                {formatDuration(stats.totalWorked)}
              </h3>
            </div>
            <div className="neu-icon-btn text-white">
              <Calendar size={20} />
            </div>
          </div>
          <div className="neu-flat p-6 flex items-center justify-between border border-white/5">
            <div>
              <p className="text-slate-400 text-xs font-bold uppercase tracking-wider mb-1">
                Heures Nuit
              </p>
              <h3 className="text-2xl font-bold text-white glow-text">
                {formatDuration(stats.nightHoursTotal)}
              </h3>
            </div>
            <div className="neu-icon-btn text-white">
              <Moon size={20} />
            </div>
          </div>
          <div className="neu-flat p-6 flex items-center justify-between border border-white/5">
            <div>
              <p className="text-slate-400 text-xs font-bold uppercase tracking-wider mb-1">
                Récupération
              </p>
              <h3 className="text-2xl font-bold text-white glow-text">
                {formatDuration(stats.overtimeTotal)}
              </h3>
            </div>
            <div className="neu-icon-btn text-white">
              <PlusCircle size={20} />
            </div>
          </div>
          <div className="neu-flat p-6 flex items-center justify-between border border-white/5">
            <div>
              <p className="text-slate-400 text-xs font-bold uppercase tracking-wider mb-1">
                Reste Sem.
              </p>
              <h3 className="text-2xl font-bold text-white glow-text">
                {formatDuration(stats.remainingContract)}
              </h3>
            </div>
            <div className="neu-icon-btn text-white">
              <Clock size={20} />
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 print:hidden">
          <div className="lg:col-span-2 neu-flat p-8 flex flex-col items-center justify-center relative overflow-hidden border border-white/5">
            <h2 className="text-lg font-bold text-slate-300 mb-6 flex items-center gap-2 glow-text">
              <div
                className={`w-3 h-3 rounded-full ${
                  timerStart ? 'bg-white animate-pulse' : 'bg-slate-600'
                }`}
              ></div>{' '}
              Pointeur Live
            </h2>
            <div className="neu-pressed px-12 py-8 mb-8 rounded-[20px] flex items-center justify-center border border-white/5">
              <div className="text-6xl font-mono font-bold text-white tracking-widest text-shadow-lg glow-text">
                {timerStart
                  ? new Date(elapsed).toISOString().substr(11, 8)
                  : '00:00:00'}
              </div>
            </div>
            <div className="flex gap-8 w-full justify-center max-w-md">
              {!timerStart ? (
                <button
                  onClick={handleStart}
                  className="flex-1 py-4 neu-btn text-white font-bold text-lg flex items-center justify-center gap-3 hover:text-slate-200 active:scale-95 transition-transform glow-text"
                >
                  <Play fill="currentColor" size={24} /> COMMENCER
                </button>
              ) : (
                <button
                  onClick={handleStop}
                  className="flex-1 py-4 neu-btn text-white font-bold text-lg flex items-center justify-center gap-3 hover:text-slate-200 active:scale-95 transition-transform glow-text"
                >
                  <Square fill="currentColor" size={24} /> TERMINER
                </button>
              )}
            </div>
          </div>

          <div className="neu-flat p-6 border border-white/5">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-lg font-bold text-slate-300 glow-text">
                Entrée Manuelle
              </h2>
              <button
                onClick={() => setShowManualForm(!showManualForm)}
                className="neu-icon-btn text-white"
              >
                {showManualForm ? <X size={20} /> : <PlusCircle size={20} />}
              </button>
            </div>

            {showManualForm ? (
              <form onSubmit={handleManualAdd} className="space-y-5 relative">
                {isAnalyzing && (
                  <div className="absolute inset-0 z-10 flex flex-col items-center justify-center text-white backdrop-blur-sm rounded-xl">
                    <Loader2 className="animate-spin w-8 h-8 mb-2" />
                    <span className="text-sm font-bold glow-text">
                      Lecture IA...
                    </span>
                  </div>
                )}
                <div className="mb-4">
                  <div className="relative">
                    <input
                      type="file"
                      accept="image/*"
                      capture="environment"
                      onChange={handleImageAnalysis}
                      className="hidden"
                      id="cameraInput"
                    />
                    <label
                      htmlFor="cameraInput"
                      className="flex items-center justify-center gap-3 w-full py-4 neu-btn text-white font-bold cursor-pointer hover:text-slate-200 active:scale-95 transition-transform glow-text"
                    >
                      <Camera size={20} /> <span>Scanner Fiche</span>
                    </label>
                  </div>
                </div>
                <div className="h-px bg-white/10 w-full mx-auto shadow-[0_1px_0_#000]"></div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-2 ml-1">
                    DATE
                  </label>
                  <input
                    type="date"
                    required
                    className="w-full p-3 neu-pressed rounded-xl bg-transparent border-none outline-none text-white font-medium glow-input"
                    value={manualDate}
                    onChange={(e) => setManualDate(e.target.value)}
                  />
                </div>
                <div className="flex items-center gap-3 p-3 neu-pressed rounded-xl">
                  <input
                    type="checkbox"
                    id="offDay"
                    className="w-5 h-5 text-white rounded focus:ring-0 cursor-pointer accent-white grayscale"
                    checked={isOffDay}
                    onChange={(e) => setIsOffDay(e.target.checked)}
                  />
                  <label
                    htmlFor="offDay"
                    className="text-sm font-bold text-slate-400 flex items-center gap-2 cursor-pointer select-none"
                  >
                    <Coffee size={18} className="text-white" /> Jour de
                    Récupération
                  </label>
                </div>
                {!isOffDay && (
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-500 mb-2 ml-1">
                        DÉBUT
                      </label>
                      <input
                        type="time"
                        className="w-full p-3 neu-pressed rounded-xl bg-transparent border-none outline-none text-white font-medium glow-input"
                        value={manualStart}
                        onChange={(e) => setManualStart(e.target.value)}
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-500 mb-2 ml-1">
                        FIN
                      </label>
                      <input
                        type="time"
                        className="w-full p-3 neu-pressed rounded-xl bg-transparent border-none outline-none text-white font-medium glow-input"
                        value={manualEnd}
                        onChange={(e) => setManualEnd(e.target.value)}
                      />
                    </div>
                  </div>
                )}
                <button
                  type="submit"
                  className="w-full py-3 neu-btn text-white font-bold hover:text-slate-200 active:scale-95 transition-transform glow-text"
                >
                  {!manualStart && !manualEnd
                    ? 'VALIDER RÉCUPÉRATION'
                    : 'VALIDER'}
                </button>
              </form>
            ) : (
              <div className="text-center py-10 text-slate-500 flex flex-col items-center">
                <div className="neu-pressed p-4 rounded-full mb-4 border border-white/5">
                  <FileText className="text-slate-600" size={32} />
                </div>
                <p className="text-sm font-medium">
                  Scanner ou Saisie Manuelle
                </p>
              </div>
            )}
          </div>
        </div>

        <div className="neu-flat p-6 overflow-hidden border border-white/5">
          <div className="flex justify-between items-center mb-6 px-2">
            <h2 className="text-lg font-bold text-slate-300 glow-text">
              Historique
            </h2>
            <div className="text-xs font-bold text-slate-400 bg-white/5 px-3 py-1 rounded-full border border-white/5">
              30h/sem • 20h-06h
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead className="text-slate-500 text-xs uppercase font-bold tracking-wider border-b border-white/5">
                <tr>
                  <th className="p-4">Date</th>
                  <th className="p-4">Horaires</th>
                  <th className="p-4 text-center">Total</th>
                  <th className="p-4 text-center">Nuit</th>
                  <th className="p-4 text-center">Jour</th>
                  <th className="p-4 text-center">Type</th>
                  <th className="p-4 text-right print:hidden"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 text-sm text-slate-300">
                {entries.length === 0 ? (
                  <tr>
                    <td
                      colSpan="7"
                      className="p-8 text-center text-slate-500 italic"
                    >
                      Aucune donnée enregistrée
                    </td>
                  </tr>
                ) : (
                  entries.map((entry) => {
                    if (!entry.endTime && entry.type !== 'off') return null;
                    const start = entry.startTime.toDate
                      ? entry.startTime.toDate()
                      : new Date(entry.startTime);
                    let end, details;
                    if (entry.type === 'off') {
                      details = { totalHours: 0, nightHours: 0, dayHours: 0 };
                    } else {
                      end = entry.endTime.toDate
                        ? entry.endTime.toDate()
                        : new Date(entry.endTime);
                      details = calculateDayNightSplit(start, end);
                    }
                    return (
                      <tr
                        key={entry.id}
                        className="hover:bg-white/5 transition-colors"
                      >
                        <td className="p-4 font-bold text-white glow-text">
                          {start.toLocaleDateString('fr-BE', {
                            weekday: 'short',
                            day: 'numeric',
                            month: 'short',
                          })}
                        </td>
                        <td className="p-4">
                          {entry.type === 'off' ? (
                            <span className="text-slate-500 italic font-medium">
                              Récupération
                            </span>
                          ) : (
                            <span className="font-mono text-slate-400">{`${start.toLocaleTimeString(
                              'fr-BE',
                              { hour: '2-digit', minute: '2-digit' }
                            )} - ${end.toLocaleTimeString('fr-BE', {
                              hour: '2-digit',
                              minute: '2-digit',
                            })}`}</span>
                          )}
                        </td>
                        {entry.type === 'off' ? (
                          <>
                            <td className="p-4 text-center text-slate-600">
                              -
                            </td>
                            <td className="p-4 text-center text-slate-600">
                              -
                            </td>
                            <td className="p-4 text-center text-slate-600">
                              -
                            </td>
                          </>
                        ) : (
                          <>
                            <td className="p-4 text-center font-bold text-white glow-text">
                              {formatDuration(details.totalHours)}
                            </td>
                            <td className="p-4 text-center text-white font-medium glow-text">
                              {details.nightHours > 0
                                ? formatDuration(details.nightHours)
                                : '-'}
                            </td>
                            <td className="p-4 text-center text-white font-medium glow-text">
                              {formatDuration(details.dayHours)}
                            </td>
                          </>
                        )}
                        <td className="p-4 text-center">
                          {entry.type === 'off' ? (
                            <span className="px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wide bg-slate-700 text-slate-400 border border-slate-600">
                              Récup
                            </span>
                          ) : (
                            <span
                              className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wide border bg-white/5 text-white border-white/20`}
                            >
                              {entry.isManual ? 'Manuel' : 'Badgeuse'}
                            </span>
                          )}
                        </td>
                        <td className="p-4 text-right print:hidden">
                          <button
                            onClick={() => initiateDelete(entry.id)}
                            className="neu-icon-btn w-8 h-8 text-slate-500 hover:text-white"
                          >
                            <Trash2 size={14} />
                          </button>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
        <div className="hidden print:block text-center text-xs text-slate-400 mt-8">
          <p>
            Généré le {new Date().toLocaleDateString('fr-BE')}. Certifié
            conforme.
          </p>
        </div>
      </main>
    </div>
  );
};

export default function App() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (u) => {
      setUser(u);
      setLoading(false);
    });
    return unsubscribe;
  }, []);

  if (loading)
    return (
      <div className="h-screen flex items-center justify-center neu-bg text-white">
        <Loader2 className="animate-spin" size={32} />
      </div>
    );
  return user ? (
    <Dashboard currentUser={user} logout={() => signOut(auth)} />
  ) : (
    <Auth setUser={setUser} />
  );
}
